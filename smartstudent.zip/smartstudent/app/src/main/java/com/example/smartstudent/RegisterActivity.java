package com.example.smartstudent;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    EditText edtUsername, edtPassword, edtRepeat;
    Button btnRegister;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // اتصال ویوها
        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        edtRepeat   = findViewById(R.id.edtRepeat);
        btnRegister = findViewById(R.id.btnLogin);

        // نوع ورودی رمز
        edtPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        edtRepeat.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        sp = getSharedPreferences("user_data", MODE_PRIVATE);

        btnRegister.setOnClickListener(v -> {
            String username = edtUsername.getText().toString().trim();
            String password = edtPassword.getText().toString().trim();
            String repeat = edtRepeat.getText().toString().trim();

            // چک خالی بودن فیلدها
            if(username.isEmpty() || password.isEmpty() || repeat.isEmpty()){
                Toast.makeText(this,"تمام فیلدها را پر کنید", Toast.LENGTH_SHORT).show();
                return;
            }

            // بررسی اینکه آیا کاربر با این نام‌کاربری ثبت‌نام کرده است یا نه
            if (username.equals(sp.getString("username", ""))) {
                Toast.makeText(this, "کاربر با این نام کاربری قبلاً ثبت‌نام کرده است", Toast.LENGTH_SHORT).show();
                return;
            }

            // حداقل طول رمز
            if(password.length() < 6){
                Toast.makeText(this,"رمز باید حداقل ۶ کاراکتر باشد", Toast.LENGTH_SHORT).show();
                return;
            }

            // بررسی شامل بودن حداقل یک عدد و یک حرف
            if(!password.matches(".*[0-9].*") || !password.matches(".*[A-Za-z].*")){
                Toast.makeText(this,"رمز باید شامل حداقل یک عدد و یک حرف باشد", Toast.LENGTH_SHORT).show();
                return;
            }

            // چک تکرار رمز
            if(!password.equals(repeat)){
                Toast.makeText(this,"رمزها یکسان نیستند", Toast.LENGTH_SHORT).show();
                return;
            }

            // ذخیره اطلاعات کاربر
            sp.edit()
                    .putString("username", username)
                    .putString("password", password)
                    .putBoolean("isLoggedIn", true)
                    .apply();

            Toast.makeText(this,"ثبت نام با موفقیت انجام شد", Toast.LENGTH_SHORT).show();

            // ورود مستقیم به MainActivity
            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

    }
}
