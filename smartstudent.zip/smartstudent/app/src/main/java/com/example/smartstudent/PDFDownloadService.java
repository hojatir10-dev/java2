package com.example.smartstudent;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class PDFDownloadService extends Service {

    public static final String CHANNEL_ID = "pdf_download_channel";
    public static final String PDF_URL = "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf";
    public static final String FILE_NAME = "Unit1.pdf";

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null; // بدون bind
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(this::downloadPDF).start();
        return START_NOT_STICKY;
    }

    private void downloadPDF() {
        try {
            URL url = new URL(PDF_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                sendNotification("دانلود PDF شکست خورد: پاسخ نامعتبر");
                stopSelf();
                return;
            }

            InputStream input = connection.getInputStream();
            File file = new File(getFilesDir(), FILE_NAME);
            FileOutputStream output = new FileOutputStream(file);

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = input.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }

            output.close();
            input.close();
            connection.disconnect();

            sendNotification("PDF با موفقیت دانلود شد!");

        } catch (Exception e) {
            e.printStackTrace();
            sendNotification("خطا در دانلود PDF");
        }
        stopSelf();
    }

    private void sendNotification(String message) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("PDF Download")
                .setContentText(message)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(2, builder.build());
    }
}
