package com.example.smartstudent;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class StudyService extends Service {

    public static final String ACTION_UPDATE = "STUDY_TIME_UPDATE";
    private Handler handler;
    private int seconds = 0;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        handler = new Handler();
        handler.post(timerRunnable);
        return START_STICKY;
    }

    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            seconds++;

            Intent intent = new Intent(ACTION_UPDATE);
            intent.putExtra("seconds", seconds);
            sendBroadcast(intent);

            if (seconds % 1800 == 0) {
                sendNotification();
            }

            handler.postDelayed(this, 1000);
        }
    };

    private void sendNotification() {
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this, "study_channel")
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle("یادآوری مطالعه")
                        .setContentText("۳۰ دقیقه مطالعه کردی 👌")
                        .setAutoCancel(true);

        NotificationManagerCompat.from(this).notify(10, builder.build());
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(timerRunnable);
        super.onDestroy();
    }
}
