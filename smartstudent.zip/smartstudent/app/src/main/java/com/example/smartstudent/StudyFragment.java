package com.example.smartstudent;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class StudyFragment extends Fragment {

    TextView tvTimer;
    BroadcastReceiver receiver;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_study_fragment, container, false);
        tvTimer = view.findViewById(R.id.tvTimer);

        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                int sec = intent.getIntExtra("seconds", 0);
                tvTimer.setText("زمان مطالعه: " + (sec / 60) + " دقیقه");
            }
        };

        requireContext().registerReceiver(
                receiver, new IntentFilter(StudyService.ACTION_UPDATE));

        return view;
    }

    @Override
    public void onDestroyView() {
        requireContext().unregisterReceiver(receiver);
        super.onDestroyView();
    }
}
